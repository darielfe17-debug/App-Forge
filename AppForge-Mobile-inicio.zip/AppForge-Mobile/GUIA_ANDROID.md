# AppForge Mobile 0.1 — empieza desde Android

## Qué se entrega
Proyecto Android nativo Java, sin WebView, editor vertical de una pantalla. Cuatro componentes, propiedades, orden, vista previa, acción Toast en botones, deshacer (30 pasos por sesión), guardado automático, importación/exportación JSON y exportación de Activity Java. Sin permisos de almacenamiento: usa el selector de archivos Android.
No es la versión final ni una APK compilada. No se ha compilado o probado en un dispositivo en este entorno, que no dispone de Android SDK/Gradle. El workflow permite realizar esa verificación.

## Compilar desde el celular sin PC
1. Descarga y extrae el ZIP con tu gestor de archivos.
2. En github.com, inicia sesión y crea un repositorio privado llamado AppForge-Mobile. Nunca subas contraseñas o claves.
3. Abre un GitHub Codespace desde ese repositorio: Code → Codespaces → Create codespace. Puede pedir habilitar el servicio y tiene cuotas; revisa lo que muestre tu cuenta. Usa el navegador en modo escritorio si no ves el menú.
4. En el explorador del Codespace, sube el ZIP a la raíz; abre Terminal → New terminal.
5. Si el archivo conserva el nombre entregado, ejecuta:

```bash
unzip AppForge-Mobile-inicio.zip
cp -r AppForge-Mobile/. .
rm -r AppForge-Mobile
rm AppForge-Mobile-inicio.zip
git add .
git commit -m "Iniciar AppForge Mobile"
git push
```

Los comandos presuponen un repositorio nuevo y vacío. No ejecutarlos en otro proyecto existente. La copia incluye .github/workflows.
6. En GitHub → Actions → Construir APK, abre la ejecución. Cuando termine correctamente, descarga AppForge-Mobile-APK en Artifacts. Extrae el ZIP e instala app-debug.apk.
7. Android puede pedir autorizar a tu navegador/gestor para instalar apps. Autoriza solo ese origen cuando lo solicite.
8. Si falla, abre el paso rojo y comparte el texto del error; no copies tokens. Una APK debug sirve para pruebas; la versión publicable requerirá firma release.

## Primera prueba
Añade Texto y cambia su contenido. Añade un Botón y configura el mensaje. Pulsa Probar y toca el botón. Vuelve a Editar, cambia el orden, prueba Deshacer. Cierra y abre la aplicación: debe conservar el diseño. Exporta JSON, crea un proyecto nuevo e importa el JSON: debe recuperar el diseño. Prueba que un JSON inválido muestre un error sin sustituir el proyecto.

## Activity exportada
GeneratedActivity.java es código nativo para integrar en OTRO proyecto Android con namespace com.pana.generated y manifest que declare esa Activity. No es una APK ni un proyecto autónomo. Solo genera la pantalla y la acción de mensaje; las entradas no persisten sus valores.

## Herramientas
JDK 17, Gradle 8.9, AGP 8.7.3, Android SDK 35, Android mínimo 8.0. El workflow instala las herramientas en el servidor, no en tu Redmi.
