package com.pana.appforge;

import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;

public class MainActivity extends Activity {
    JSONObject project; LinearLayout root, list; boolean preview=false;
    ArrayDeque<String> undo=new ArrayDeque<>(); String pending="";
    final int ink=Color.rgb(230,233,245), accent=Color.rgb(139,111,255);
    @Override public void onCreate(Bundle b){super.onCreate(b); load(); draw();}
    void load(){try{project=new JSONObject(getPreferences(0).getString("project", "")); validate(project);}catch(Exception e){project=fresh();}}
    JSONObject fresh(){try{return new JSONObject("{\"version\":1,\"name\":\"Mi primera app\",\"components\":[]}");}catch(Exception e){throw new RuntimeException(e);}}
    JSONArray items(){return project.optJSONArray("components");}
    void checkpoint(){undo.push(project.toString());if(undo.size()>30)undo.removeLast();}
    void save(){getPreferences(0).edit().putString("project",project.toString()).apply();}
    void changed(){save();draw();}
    TextView label(String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(ink);v.setPadding(10,12,10,12);return v;}
    void button(LinearLayout box,String t,Runnable r){Button b=new Button(this);b.setText(t);b.setAllCaps(false);box.addView(b);b.setOnClickListener(v->r.run());}
    void draw(){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(20,24,20,16);root.setBackgroundColor(Color.rgb(15,18,31));setContentView(root);
        root.addView(label("APPFORGE  /  MOBILE",24));root.addView(label(project.optString("name")+(preview?" · Vista previa":" · Editor"),17));
        LinearLayout nav=new LinearLayout(this);root.addView(nav);
        button(nav,preview?"Editar":"Probar",()->{preview=!preview;draw();});
        button(nav,"Deshacer",()->{if(!undo.isEmpty()){try{project=new JSONObject(undo.pop());changed();}catch(Exception e){error(e);}}});
        button(nav,"Menú",this::menu);
        if(!preview)button(root,"+ Añadir componente",this::add);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);
        if(items().length()==0)list.addView(label("Tu app comienza aquí. Añade texto, entradas, botones o interruptores.",18));
        for(int i=0;i<items().length();i++){final int index=i;JSONObject c=items().optJSONObject(i);if(c==null)continue;
            String type=c.optString("type"),text=c.optString("text");
            if(preview){switch(type){
                case "input": EditText input=new EditText(this);input.setHint(text);input.setTextColor(ink);input.setHintTextColor(Color.GRAY);list.addView(input);break;
                case "switch": Switch sw=new Switch(this);sw.setText(text);sw.setTextColor(ink);list.addView(sw);break;
                case "button":button(list,text,()->Toast.makeText(this,c.optString("message","¡Funciona!"),Toast.LENGTH_SHORT).show());break;
                default: list.addView(label(text,20));
            }}else{LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(12,10,12,10);card.setBackgroundColor(Color.rgb(29,33,52));list.addView(card);card.addView(label((i+1)+" · "+type+"\n"+text,18));LinearLayout actions=new LinearLayout(this);card.addView(actions);
                button(actions,"Editar",()->edit(index));button(actions,"↑",()->move(index,-1));button(actions,"↓",()->move(index,1));button(actions,"×",()->{checkpoint();items().remove(index);changed();});
            }
        }
        root.addView(label(preview?"Los valores de prueba se reinician al salir.":"Guardado automático · "+items().length()+" componentes",12));
    }
    void add(){new AlertDialog.Builder(this).setTitle("Componentes nativos").setItems(new String[]{"Texto","Botón","Entrada","Interruptor"},(d,n)->{try{checkpoint();JSONObject c=new JSONObject();c.put("type",new String[]{"text","button","input","switch"}[n]);c.put("text",new String[]{"Hola, pana","Tócame","Escribe aquí","Activar opción"}[n]);c.put("message","¡Mi primera acción!");items().put(c);changed();}catch(Exception e){error(e);}}).show();}
    void edit(int i){JSONObject c=items().optJSONObject(i);LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(24,12,24,12);EditText text=new EditText(this);text.setText(c.optString("text"));box.addView(text);EditText message=new EditText(this);message.setHint("Mensaje al pulsar");message.setText(c.optString("message"));if(c.optString("type").equals("button"))box.addView(message);
        new AlertDialog.Builder(this).setTitle("Propiedades").setView(box).setPositiveButton("Guardar",(d,n)->{try{checkpoint();c.put("text",text.getText().toString());c.put("message",message.getText().toString());changed();}catch(Exception e){error(e);}}).setNegativeButton("Cancelar",null).show();}
    void move(int i,int delta){int j=i+delta;if(j<0||j>=items().length())return;try{checkpoint();Object a=items().get(i),b=items().get(j);items().put(i,b);items().put(j,a);changed();}catch(Exception e){error(e);}}
    void menu(){new AlertDialog.Builder(this).setItems(new String[]{"Renombrar proyecto","Exportar proyecto JSON","Importar proyecto JSON","Exportar Activity Java","Nuevo proyecto"},(d,n)->{switch(n){
        case 0:EditText name=new EditText(this);name.setText(project.optString("name"));new AlertDialog.Builder(this).setTitle("Nombre").setView(name).setPositiveButton("Guardar",(x,y)->{try{checkpoint();project.put("name",name.getText().toString());changed();}catch(Exception e){error(e);}}).setNegativeButton("Cancelar",null).show();break;
        case 1:export(project.toString(),"proyecto.appforge.json","application/json");break;
        case 2:Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("*/*");in.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(in,2);break;
        case 3:export(source(),"GeneratedActivity.java","text/plain");break;
        case 4:new AlertDialog.Builder(this).setMessage("¿Reemplazar el proyecto actual? Puedes exportarlo antes.").setPositiveButton("Nuevo",(x,y)->{checkpoint();project=fresh();changed();}).setNegativeButton("Cancelar",null).show();break;
    }}).show();}
    void export(String data,String name,String mime){pending=data;Intent in=new Intent(Intent.ACTION_CREATE_DOCUMENT);in.setType(mime);in.addCategory(Intent.CATEGORY_OPENABLE);in.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(in,1);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;try{Uri uri=data.getData();if(req==1){try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(pending.getBytes(StandardCharsets.UTF_8));}Toast.makeText(this,"Exportado",0).show();}else if(req==2){ByteArrayOutputStream buffer=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(buffer.size()+n>2000000)throw new IOException("Máximo 2 MB");buffer.write(b,0,n);}}JSONObject imported=new JSONObject(buffer.toString("UTF-8"));validate(imported);checkpoint();project=imported;changed();}}catch(Exception e){error(e);}}
    void validate(JSONObject p)throws Exception{if(p.optInt("version")!=1||!p.has("name")||!(p.opt("components") instanceof JSONArray))throw new IOException("Proyecto incompatible");JSONArray a=p.getJSONArray("components");if(a.length()>200)throw new IOException("Máximo 200 componentes");for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);String t=c.getString("type");if(!t.equals("text")&&!t.equals("button")&&!t.equals("input")&&!t.equals("switch"))throw new IOException("Componente desconocido");c.getString("text");}}
    String quote(String s){StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray()){switch(c){case '\\':b.append("\\\\");break;case '"':b.append("\\\"");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}}return b.append('"').toString();}
    String source(){StringBuilder s=new StringBuilder("package com.pana.generated;\nimport android.app.Activity;\nimport android.os.Bundle;\nimport android.widget.*;\npublic class GeneratedActivity extends Activity {\n public void onCreate(Bundle state){super.onCreate(state);ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,24);scroll.addView(root);setContentView(scroll);\n");for(int i=0;i<items().length();i++){JSONObject c=items().optJSONObject(i);String v="v"+i,t=c.optString("type"),text=quote(c.optString("text"));String cls=t.equals("button")?"Button":t.equals("input")?"EditText":t.equals("switch")?"Switch":"TextView";s.append(cls+" "+v+"=new "+cls+"(this);"+v+(t.equals("input")?".setHint(":".setText(")+text+");root.addView("+v+");\n");if(t.equals("button"))s.append(v+".setOnClickListener(view->Toast.makeText(this,"+quote(c.optString("message"))+",Toast.LENGTH_SHORT).show());\n");}return s.append("}\n}\n").toString();}
    void error(Exception e){new AlertDialog.Builder(this).setTitle("No se pudo completar").setMessage(e.getMessage()).setPositiveButton("Aceptar",null).show();}
}
