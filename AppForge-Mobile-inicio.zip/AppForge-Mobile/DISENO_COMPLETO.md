# AppForge Mobile — visión de producto

Objetivo: crear aplicaciones Android desde Android, con trabajo local y compilación remota opcional. El primer objetivo medible es producir una app de dos pantallas con formulario, datos guardados y APK instalable.

## Funciones finales propuestas (pendientes salvo lo indicado)
- Inicio: múltiples proyectos, búsqueda, duplicación, plantillas y recuperación de versiones.
- Diseñador: pantallas y árbol de componentes; texto, botones, entradas, imágenes, tarjetas, listas, navegación; selección táctil y arrastre, estilos, temas, tamaños adaptativos y accesibilidad.
- Lógica: bloques tipados de eventos, variables, condiciones, listas, navegación, validación y almacenamiento. Detectar conexiones inválidas antes de compilar.
- Datos: tablas locales, formularios, importación CSV, búsquedas; API HTTP con autenticación mediante backend propio cuando haya secretos.
- Pruebas: simulador de datos, registro de eventos, inspección de variables y advertencias de accesibilidad.
- Exportación: proyecto Gradle independiente, código legible, recursos y pruebas; compilación remota con estado, logs, descarga APK y firma release separada.
- IA opcional: instrucciones en español que propongan cambios estructurados, validación de esquema y revisión antes de aplicarlos. Requiere un proveedor/modelo y backend; no poner claves de servicio en la APK.
- Innovaciones: modo Aprender que explica el código de cada bloque; comparación visual entre versiones; presupuesto de rendimiento para teléfonos modestos; kit de plantillas dominicanas (catálogo en RD$, pedidos, estudio).

## Tecnología y arquitectura
La base 0.1 usa Java y vistas nativas Android para reducir dependencias. Evolución propuesta: Kotlin, Jetpack Compose para editor, Room para múltiples proyectos, coroutines para tareas y WorkManager para transferencias. Migrar preservando el esquema JSON versionado.
Separar modelo Project/Screen/Component/Action, validador, renderer nativo, generador de código y repositorio. En 0.1 estas responsabilidades están juntas en una Activity y deben separarse antes de ampliar.
El modelo guardará identificadores estables y referencias tipadas; futuras migraciones deberán soportar proyectos v1.
Compilación: exportador genera una plantilla Gradle, un servicio construye en contenedores aislados con límites y devuelve APK/logs. No ejecutar código de terceros en el teléfono ni prometer compilar cualquier proyecto sin conexión.
Firma: claves bajo control del usuario; no añadirlas al repositorio. Servicio futuro requerirá autenticación, cuotas, retención y limpieza de archivos.

## Estado real 0.1
Hecho en código: una pantalla, cuatro componentes, edición, reordenación con flechas, preview con mensajes, guardado local, deshacer, JSON e Activity Java.
Pendiente: arrastre, proyectos múltiples, navegación, lógica por bloques, persistencia de datos de apps creadas, exportación Gradle completa, IA, servicio compilador, firma release y colaboración.
Verificación: inspección de estructura y sintaxis; compilación Android y pruebas físicas pendientes. El workflow entrega APK solo si compila correctamente.

## Etapas y criterios de cierre
1. Validar 0.1 en el celular: instalar, editar, guardar, importar y probar botones.
2. Separar arquitectura, múltiples proyectos y pantallas: dos proyectos independientes y navegación funcional en preview/export.
3. Datos y lógica: formulario valida y guarda registros incluso después de reiniciar la app generada.
4. Exportador completo: ZIP Gradle compila en CI y produce una app independiente equivalente al preview.
5. Bloques e IA: cambios revisables, deshacer y diagnósticos; añadir asistencia IA solo con proveedor configurado.
6. Publicación: firma release, iconos, accesibilidad, pruebas de rendimiento y requisitos de tienda.

No hay plazos garantizados: cada etapa se cierra con una prueba funcional. Empezaremos con una app de lista de tareas como plantilla verificable.
